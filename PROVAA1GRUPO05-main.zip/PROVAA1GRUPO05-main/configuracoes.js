/**
 * Arquivo de configuração de variáveis do projeto.
 */

// Requisito: cidadeImaginaria trocada por cidadeDosBolseiros
const cidadeDoMapa = "cidadeDosBolseiros"; 
const nivelZoom = 15;

console.log(`Configuração carregada. Mapa focado em: ${cidadeDoMapa}`);