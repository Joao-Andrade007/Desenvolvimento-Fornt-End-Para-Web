(function ($) {
    $(function () {
        $('.sidenav').sidenav();
    });
    $('.parallax').parallax();
})(jQuery);